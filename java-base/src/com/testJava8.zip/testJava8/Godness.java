package com.testJava8;

/**
 * @ClassName Godness
 * @Author: ChenBJ
 * @Description: TODO
 * @Date: 2018/8/17 18:27
 * @Version:
 */
public class Godness {
    private String name;

    public Godness() {
    }

    public Godness(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Godness [name=" + name + "]";
    }
}
