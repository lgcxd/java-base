package com.testJava8;
@FunctionalInterface
public interface MyFun2 {
    String getStr(String str);
}
