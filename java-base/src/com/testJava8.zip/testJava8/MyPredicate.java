package com.testJava8;

public interface MyPredicate<T> {
    public boolean test(T t);
}
