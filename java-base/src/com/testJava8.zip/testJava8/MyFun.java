package com.testJava8;
@FunctionalInterface
public interface MyFun {
    public Integer getVlue(Integer num);
}
